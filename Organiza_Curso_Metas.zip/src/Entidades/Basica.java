package Entidades;

public class Basica extends Disciplina{

    public Basica(String nome, String codigo, String preRequisito, String area, String tipo, String horario, String periodo) {
        super(nome, codigo, preRequisito, area, tipo, horario, periodo);
    }

}
