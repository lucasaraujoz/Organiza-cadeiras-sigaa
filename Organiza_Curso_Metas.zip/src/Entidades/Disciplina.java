package Entidades;

public class Disciplina {
    private String nome;
    private String codigo;
    private String preRequisito;
    private String area;
    private String tipo;
    private String horario;
    private String periodo;
    private float nota = 0;
    public Disciplina(String nome, String codigo, String preRequisito,
                      String area,String tipo,String horario,String periodo) {
        this.nome = nome;
        this.codigo = codigo;
        this.preRequisito = preRequisito;
        this.area = area;
        this.tipo = tipo;
        this.horario = horario;
        this.periodo = periodo;
    }


    public float getNota() {
        return nota;
    }

    public void setNota(float nota) {
        this.nota = nota;
    }

    public String getNome() {
        return nome;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getPreRequisito() {
        return preRequisito;
    }

    public String getPeriodo() {
        return periodo;
    }

    public String getTipo() {
        return tipo;
    }

    public String getHorario() {
        return horario;
    }
}
