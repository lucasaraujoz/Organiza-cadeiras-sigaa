package Entidades;

public class Eletiva_2 extends Disciplina {

    public Eletiva_2(String nome, String codigo, String preRequisito, String area, String tipo, String horario, String periodo) {
        super(nome, codigo, preRequisito, area, tipo, horario, periodo);
    }

}
