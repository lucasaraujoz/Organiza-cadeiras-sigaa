package Controler;

import Entidades.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class DisciplinasControler {
    private ArrayList<Aluno> usuarios = new ArrayList<>();
    private Map<String, Disciplina> mapDisciplinas;

    public DisciplinasControler() throws IOException {
        mapDisciplinas = importMapDisciplinas();
    }

    private Map<String, Disciplina> importMapDisciplinas() throws IOException {
        Map<String, Disciplina> disciplinas = new TreeMap<>();
        BufferedReader br = new BufferedReader(new FileReader("src/Disciplinas.csv"));
        String linha = "";
        br.readLine(); // pula a primeira linha
        br.readLine(); //pula o #1
        int periodo = 1;
        while ((linha = br.readLine()) != null) {
            if (!linha.contains("#")) {
                String[] dados = linha.split(";");
                String nome = dados[0].strip();
                String cod = dados[1].strip();
                String prereq = dados[2].strip();
                String area = dados[3].strip();
                String tipo = dados[4].strip();
                String horario = dados[5].strip();
                String periodo_str = String.valueOf(periodo).strip();
                switch (tipo) {
                    case "BASICA" -> {
                        disciplinas.put(cod, new Basica(nome, cod, prereq, area, tipo, horario, periodo_str));
                    }
                    case "EL1" -> {
                        disciplinas.put(cod, new Eletiva_1(nome, cod, prereq, area, tipo, horario, periodo_str));
                    }
                    case "EL2" -> {
                        disciplinas.put(cod, new Eletiva_2(nome, cod, prereq, area, tipo, horario, periodo_str));
                    }
                }
            } else {
                periodo++;
            }
        }
        return disciplinas;
    }

    public Map<String, Disciplina> getMapDisciplinas() {
        return mapDisciplinas;
    }

    public void cadastrarDisciplina(Disciplina disciplina) {
        this.mapDisciplinas.put(disciplina.getCodigo(), disciplina);
    }
    public ArrayList<Aluno> getUsuarios() {
        return usuarios;
    }

    public void cadastrarUsuario(Aluno usuario) {
        this.usuarios.add(usuario);
    }
}
